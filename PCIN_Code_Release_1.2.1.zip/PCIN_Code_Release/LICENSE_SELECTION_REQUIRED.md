# Licence selection required

This prepared code release does not include a licence. Before making it public, the author must choose the reuse terms.

Suggested option for the original Python code: MIT License. This is a recommendation, not a licence applied by this package. Confirm that the author owns or has permission to license all included code. The manuscript and figures should be handled under a separately selected licence or retained under their own copyright notice; do not automatically apply the code licence to them.
