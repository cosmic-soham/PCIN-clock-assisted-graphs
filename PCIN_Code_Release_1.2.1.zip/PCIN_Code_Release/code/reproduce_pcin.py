#!/usr/bin/env python3
"""Reproduce the finite-volume PCIN model checks and manuscript figures.

Model: d=2 clock-modulated hard-core excitation hopping on a finite FCC graph.
Simulation units: hbar = t_P = E_P = 1, so Delta = pi.

Dependencies: numpy, scipy, matplotlib.
Run: python code/reproduce_pcin.py --outdir figures

The script performs finite-cluster checks only. It does not simulate a periodic
bulk FCC lattice or provide experimental validation of the physical postulates.
"""
from __future__ import annotations
import argparse
import itertools
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigh, expm
from scipy.spatial import ConvexHull, Voronoi
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

PI = np.pi


def fcc_primitive_vectors(ell: float = 1.0) -> np.ndarray:
    a = ell / np.sqrt(2.0)
    return a * np.array([[0., 1., 1.], [1., 0., 1.], [1., 1., 0.]])


def fcc_neighbours(ell: float = 1.0) -> np.ndarray:
    a = ell / np.sqrt(2.0)
    vecs = []
    for zero_axis in range(3):
        axes = [0, 1, 2]
        axes.remove(zero_axis)
        for s1, s2 in itertools.product((-1., 1.), repeat=2):
            v = np.zeros(3)
            v[axes[0]] = s1 * a
            v[axes[1]] = s2 * a
            vecs.append(v)
    return np.asarray(vecs)


def rhombic_dodecahedron_vertices(ell: float = 1.0) -> np.ndarray:
    a = ell / np.sqrt(2.0)
    verts = []
    for axis in range(3):
        for sign in (-1., 1.):
            v = np.zeros(3)
            v[axis] = sign * a
            verts.append(v)
    for signs in itertools.product((-1., 1.), repeat=3):
        verts.append((a / 2.0) * np.asarray(signs))
    return np.asarray(verts)


def rhombic_dodecahedron_faces(ell: float = 1.0):
    nn = fcc_neighbours(ell)
    verts = rhombic_dodecahedron_vertices(ell)
    faces = []
    for normal in nn:
        ids = np.where(np.isclose(verts @ normal, ell**2 / 2.0, atol=1e-10))[0]
        poly = verts[ids]
        if len(poly) != 4:
            raise RuntimeError(f"Expected four vertices per face, got {len(poly)}")
        centre = poly.mean(axis=0)
        nvec = normal / np.linalg.norm(normal)
        trial = np.array([1., 0., 0.])
        if abs(np.dot(trial, nvec)) > 0.8:
            trial = np.array([0., 1., 0.])
        e1 = np.cross(nvec, trial)
        e1 /= np.linalg.norm(e1)
        e2 = np.cross(nvec, e1)
        ang = np.arctan2((poly - centre) @ e2, (poly - centre) @ e1)
        faces.append(poly[np.argsort(ang)])
    return faces


def validate_fcc_geometry(ell: float = 1.0) -> dict:
    nn = fcc_neighbours(ell)
    verts = rhombic_dodecahedron_vertices(ell)
    faces = rhombic_dodecahedron_faces(ell)
    edge_set = set()
    edge_lengths = []
    for face in faces:
        for a, b in zip(face, np.roll(face, -1, axis=0)):
            ia = int(np.argmin(np.linalg.norm(verts - a, axis=1)))
            ib = int(np.argmin(np.linalg.norm(verts - b, axis=1)))
            edge_set.add(tuple(sorted((ia, ib))))
    for ia, ib in edge_set:
        edge_lengths.append(float(np.linalg.norm(verts[ia] - verts[ib])))
    volume = float(ConvexHull(verts).volume)
    nearest = np.linalg.norm(nn, axis=1)
    face_sizes = [len(face) for face in faces]

    # Independent finite-point Voronoi construction from an FCC patch.
    primitive = fcc_primitive_vectors(ell)
    lattice_points = np.asarray([
        a*primitive[0] + b*primitive[1] + c*primitive[2]
        for a, b, c in itertools.product(range(-2, 3), repeat=3)
    ])
    vor = Voronoi(lattice_points)
    origin_index = int(np.argmin(np.linalg.norm(lattice_points, axis=1)))
    central_region = vor.regions[vor.point_region[origin_index]]
    if -1 in central_region:
        raise RuntimeError("Finite FCC patch did not bound the central Voronoi region")
    vor_vertices = vor.vertices[central_region]
    distance_matrix = np.linalg.norm(vor_vertices[:, None, :] - verts[None, :, :], axis=2)
    vor_vertex_match_error = float(max(distance_matrix.min(axis=1).max(), distance_matrix.min(axis=0).max()))
    central_ridges = [rv for (p, q), rv in zip(vor.ridge_points, vor.ridge_vertices)
                      if p == origin_index or q == origin_index]
    vor_face_sizes = [len(rv) for rv in central_ridges]
    checks = {
        "nearest_neighbour_count": int(len(nn)),
        "nearest_neighbour_distances_over_ellP": (nearest / ell).tolist(),
        "vertex_count": int(len(verts)),
        "face_count": int(len(faces)),
        "vertices_per_face": face_sizes,
        "edge_count": int(len(edge_set)),
        "edge_lengths_over_ellP": (np.asarray(edge_lengths) / ell).tolist(),
        "inradius_over_ellP": 0.5,
        "circumradius_over_ellP": float(np.max(np.linalg.norm(verts, axis=1)) / ell),
        "volume_over_ellP_cubed": volume / ell**3,
        "expected_volume_over_ellP_cubed": 1.0 / np.sqrt(2.0),
        "expected_edge_length_over_ellP": np.sqrt(6.0) / 4.0,
        "independent_voronoi_patch_site_count": int(len(lattice_points)),
        "independent_voronoi_central_vertex_count": int(len(central_region)),
        "independent_voronoi_central_face_count": int(len(central_ridges)),
        "independent_voronoi_face_vertex_counts": vor_face_sizes,
        "independent_voronoi_vertex_match_error_over_ellP": vor_vertex_match_error / ell,
    }
    assert len(nn) == 12 and np.allclose(nearest, ell)
    assert len(verts) == 14 and len(faces) == 12 and face_sizes == [4] * 12
    assert len(edge_set) == 24
    assert np.allclose(edge_lengths, np.sqrt(6.0) * ell / 4.0)
    assert np.isclose(volume, ell**3 / np.sqrt(2.0))
    assert np.isclose(np.max(np.linalg.norm(verts, axis=1)), ell / np.sqrt(2.0))
    assert np.isclose(np.min(np.linalg.norm(nn, axis=1)), ell)
    assert len(central_region) == 14 and len(central_ridges) == 12
    assert vor_face_sizes == [4] * 12 and vor_vertex_match_error < 1e-8*ell
    return checks


def make_fcc_geometry_figure(outdir: Path):
    ell = 1.0
    nn = fcc_neighbours(ell)
    verts = rhombic_dodecahedron_vertices(ell)
    faces = rhombic_dodecahedron_faces(ell)
    fig = plt.figure(figsize=(12.2, 5.2))

    # Panel A: actual local Voronoi patch: centre cell and its twelve face neighbours.
    ax = fig.add_subplot(121, projection="3d")
    neigh_cells = [verts + r for r in nn]
    for cell in neigh_cells:
        # Draw translated neighbouring cell boundaries as thin wireframe edges.
        for face in faces:
            poly = face + (cell[0] - verts[0])  # translation associated with this neighbour
            closed = np.vstack([poly, poly[0]])
            ax.plot(closed[:, 0], closed[:, 1], closed[:, 2], color="0.35", linewidth=0.48, alpha=0.55)
    central = Poly3DCollection(faces, facecolors="#8fbad8", edgecolors="#243746", linewidths=1.0, alpha=0.72)
    ax.add_collection3d(central)
    ax.scatter([0], [0], [0], s=30, color="#182b3a", depthshade=False)
    ax.scatter(nn[:, 0], nn[:, 1], nn[:, 2], s=18, color="#b13d4a", depthshade=False)
    for v in nn:
        ax.plot([0, v[0]], [0, v[1]], [0, v[2]], color="#b13d4a", linewidth=0.85, alpha=0.75)
    ax.set_title("13-cell Voronoi patch")
    ax.set_xlabel(r"$x/\ell_P$")
    ax.set_ylabel(r"$y/\ell_P$")
    # Omit first-panel z label to avoid 3D-axis clipping in journal layout.
    lim = 1.55
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(-lim, lim)
    ax.set_box_aspect((1, 1, 1)); ax.view_init(elev=22, azim=34)

    # Panel B: single exact cell, faces and equal-length centre links.
    ax2 = fig.add_subplot(122, projection="3d")
    coll = Poly3DCollection(faces, facecolors="#e6b96f", edgecolors="#263746", linewidths=1.15, alpha=0.72)
    ax2.add_collection3d(coll)
    ax2.scatter([0], [0], [0], s=35, color="#182b3a", depthshade=False)
    ax2.scatter(nn[:, 0], nn[:, 1], nn[:, 2], s=22, color="#b13d4a", depthshade=False)
    for v in nn:
        ax2.plot([0, v[0]], [0, v[1]], [0, v[2]], color="#b13d4a", linewidth=1.05)
    ax2.set_title("One rhombic-dodecahedral cell")
    ax2.set_xlabel(r"$x/\ell_P$")
    ax2.set_ylabel(r"$y/\ell_P$")
    ax2.set_zlabel(r"$z/\ell_P$")
    ax2.set_xlim(-0.95, 0.95); ax2.set_ylim(-0.95, 0.95); ax2.set_zlim(-0.95, 0.95)
    ax2.set_box_aspect((1, 1, 1)); ax2.view_init(elev=22, azim=34)

    fig.suptitle(r"FCC Voronoi spatial tessellation ($d_{\rm nn}=\ell_P$)", fontsize=14)
    fig.tight_layout()
    fig.savefig(outdir / "fig1_fcc_geometry.pdf", bbox_inches="tight")
    fig.savefig(outdir / "fig1_fcc_geometry.png", dpi=250, bbox_inches="tight")
    plt.close(fig)


def make_fcc_laplacian_figure(outdir: Path):
    q = np.linspace(1e-4, 1.8, 450)  # q = |k| ell_P
    directions = {
        "[100]": np.array([1., 0., 0.]),
        "[110]": np.array([1., 1., 0.]) / np.sqrt(2.0),
        "[111]": np.array([1., 1., 1.]) / np.sqrt(3.0),
    }
    fig, ax = plt.subplots(figsize=(6.8, 4.5))
    for label, direction in directions.items():
        proj = q[:, None] * direction[None, :] / np.sqrt(2.0)
        X, Y, Z = proj[:, 0], proj[:, 1], proj[:, 2]
        lam = 2.0 * (np.cos(X)*np.cos(Y) + np.cos(Y)*np.cos(Z) + np.cos(Z)*np.cos(X) - 3.0)
        ratio = -lam / (q**2)
        ax.plot(q, ratio, linewidth=1.7, label=label)
    ax.axhline(1.0, linestyle="--", linewidth=1.2, label=r"continuum limit $-\nabla^2$")
    ax.set_xlabel(r"dimensionless wavenumber $|\mathbf{k}|\ell_P$")
    ax.set_ylabel(r"normalised symbol $-\ell_P^2\lambda_\Delta/(|\mathbf{k}|\ell_P)^2$")
    ax.set_title("FCC graph-Laplacian directional corrections")
    ax.grid(True, linewidth=0.35, alpha=0.5)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(outdir / "fig2_fcc_laplacian.pdf", bbox_inches="tight")
    fig.savefig(outdir / "fig2_fcc_laplacian.png", dpi=250, bbox_inches="tight")
    plt.close(fig)


def make_clock_figure(outdir: Path, eta: float = 0.7):
    fig, ax = plt.subplots(figsize=(6.6, 4.4))
    styles = {2: ("o", "-"), 4: ("s", "--"), 8: ("^", ":")}
    for d, (marker, ls) in styles.items():
        delta = np.arange(d)
        f = 1.0 - eta * np.sin(np.pi * delta / d)**2
        ax.plot(delta/d, f, marker=marker, linestyle=ls, linewidth=1.5, markersize=5, label=fr"$d={d}$")
    ax.set_xlabel(r"relative phase label $(m-n)/d$ (mod 1)")
    ax.set_ylabel(r"coupling factor $f_d(m-n)$")
    ax.set_ylim(1-eta-0.06, 1.06)
    ax.grid(True, linewidth=0.35, alpha=0.5)
    ax.legend(frameon=False)
    ax.set_title(fr"Relative-clock modulation ($\eta={eta}$)")
    fig.tight_layout()
    fig.savefig(outdir / "fig3_clock_modulation.pdf", bbox_inches="tight")
    fig.savefig(outdir / "fig3_clock_modulation.png", dpi=250, bbox_inches="tight")
    plt.close(fig)


def clock_ops(n_sites: int, delta: float = PI):
    dim = 2**n_sites
    hc = np.zeros((dim, dim), dtype=complex)
    xs = []
    for state in range(dim):
        hc[state, state] = delta * sum((state >> i) & 1 for i in range(n_sites))
    for i in range(n_sites):
        x = np.zeros((dim, dim), dtype=complex)
        for state in range(dim):
            x[state ^ (1 << i), state] = 1.0
        xs.append(x)
    return hc, xs


def pair_transfer_probability(beta: float, eta: float, u: float) -> float:
    if beta < 0 or not 0.0 <= eta <= 1.0:
        raise ValueError("Require beta >= 0 and 0 <= eta <= 1.")
    hc = np.diag([0.0, PI, PI, 2.0 * PI]).astype(complex)
    x = np.array([[0., 1.], [1., 0.]], dtype=complex)
    f = (1.0 - eta/2.0)*np.eye(4) + (eta/2.0)*np.kron(x, x)
    hp, hm = hc + beta*f, hc - beta*f
    phi = np.ones(4, dtype=complex) / 2.0
    up, um = expm(-1j*hp*u), expm(-1j*hm*u)
    amp = np.vdot(phi, up.conj().T @ um @ phi)
    return float(np.clip(0.5*(1.0-amp.real), 0.0, 1.0))


def pair_transfer_closed_form(beta: float, eta: float, u: float) -> float:
    delta = beta * eta / 2.0
    omega = np.sqrt(PI**2 + delta**2)
    middle = (1.0 - 2.0*delta**2/omega**2*np.sin(omega*u)**2
              + 1j*delta/omega*np.sin(2.0*omega*u))
    amp = 0.5*(np.exp(2j*beta*(1.0-eta/2.0)*u)*middle + np.exp(2j*beta*u))
    return float(np.clip(0.5*(1.0-amp.real), 0.0, 1.0))


def make_pair_transfer_figure(outdir: Path, beta: float = 0.2):
    us = np.linspace(0, 20, 900)
    fig, ax = plt.subplots(figsize=(6.6, 4.4))
    for eta, ls, label in [(0.0, "-", r"$\eta=0$"), (0.5, "--", r"$\eta=0.5$"), (1.0, ":", r"$\eta=1$")]:
        ps = [pair_transfer_closed_form(beta, eta, u) for u in us]
        ax.plot(us, ps, linestyle=ls, linewidth=1.6, label=label)
    ax.set_xlabel(r"dimensionless evolution parameter $u=t/t_P$")
    ax.set_ylabel(r"transfer probability $P_{10\rightarrow01}(u)$")
    ax.set_ylim(-0.03, 1.03)
    ax.grid(True, linewidth=0.35, alpha=0.5)
    ax.legend(frameon=False)
    ax.set_title(fr"Exact two-cell clock-coupled dynamics ($d=2$, $\beta={beta}$)")
    fig.tight_layout()
    fig.savefig(outdir / "fig4_pair_transfer.pdf", bbox_inches="tight")
    fig.savefig(outdir / "fig4_pair_transfer.png", dpi=250, bbox_inches="tight")
    plt.close(fig)


def matter_operators(n_sites: int):
    dim = 2**n_sites
    n_ops, sp_ops, sm_ops = [], [], []
    for i in range(n_sites):
        ni = np.zeros((dim, dim), dtype=complex)
        spi = np.zeros_like(ni); smi = np.zeros_like(ni)
        for state in range(dim):
            if (state >> i) & 1:
                ni[state, state] = 1.0
                smi[state ^ (1 << i), state] = 1.0
            else:
                spi[state | (1 << i), state] = 1.0
        n_ops.append(ni); sp_ops.append(spi); sm_ops.append(smi)
    k_ops = {(i, j): sp_ops[i] @ sm_ops[j] + sm_ops[i] @ sp_ops[j]
             for i, j in itertools.combinations(range(n_sites), 2)}
    return n_ops, k_ops


def tetrahedron_exact_and_effective(j0: float, g: float, delta: float = PI):
    n_sites = 4
    dm = dc = 2**n_sites
    _, ks = matter_operators(n_sites)
    edges = list(ks)
    tmat = sum(ks.values(), np.zeros((dm, dm), dtype=complex))
    hc, xs = clock_ops(n_sites, delta)
    h = np.kron(np.eye(dm), hc) + j0*np.kron(tmat, np.eye(dc))
    for (i, j), k in ks.items():
        h += g*np.kron(k, xs[i] @ xs[j])
    # Third-order Hermitian SW effective Hamiltonian on the full matter space.
    h2 = -g**2/(2.0*delta)*sum((k@k for k in ks.values()), np.zeros_like(tmat))
    h3tri = np.zeros_like(tmat)
    for tri in itertools.combinations(range(n_sites), 3):
        tri_edges = [(tri[0], tri[1]), (tri[1], tri[2]), (tri[0], tri[2])]
        for perm in itertools.permutations(tri_edges):
            h3tri += g**3/(4.0*delta**2)*(ks[perm[0]] @ ks[perm[1]] @ ks[perm[2]])
    h3mix = np.zeros_like(tmat)
    for k in ks.values():
        comm = k @ tmat - tmat @ k
        h3mix += -g**2*j0/(8.0*delta**2)*(k @ comm - comm @ k)
    heff = j0*tmat + h2 + h3tri + h3mix
    return h, heff, ks, tmat


def low_spectrum_by_matter_sector(h, heff, n_sites=4, clock_dim=16):
    dm = 2**n_sites
    errs = {}
    for number in range(n_sites+1):
        matter_states = [s for s in range(dm) if s.bit_count() == number]
        inds = [s*clock_dim+c for s in matter_states for c in range(clock_dim)]
        hblock = h[np.ix_(inds, inds)]
        eb = eigh(hblock, eigvals_only=True, subset_by_index=[0, len(matter_states)-1]).real
        effblock = heff[np.ix_(matter_states, matter_states)]
        ee = eigh(effblock, eigvals_only=True).real
        errs[str(number)] = float(np.max(np.abs(eb-ee)))
    return errs


def make_sw_figure(outdir: Path):
    gs = np.array([0.0025, 0.005, 0.0075, 0.01, 0.015, 0.02, 0.03, 0.04])
    rows = []
    for g in gs:
        j0 = 2.0*g  # eta = 2/3, J = 3g
        h, heff, _, _ = tetrahedron_exact_and_effective(j0, g)
        errors = low_spectrum_by_matter_sector(h, heff)
        maximum = max(errors.values())
        rows.append({"g_over_EP": float(g), "J0_over_EP": float(j0), "eta": 2.0/3.0,
                     "max_abs_error": maximum, "error_over_g4": maximum/g**4,
                     "sector_errors_by_N": errors})
    slope = float(np.polyfit(np.log(gs), np.log([r["max_abs_error"] for r in rows]), 1)[0])
    fig, ax = plt.subplots(figsize=(6.6, 4.4))
    errs = np.array([r["max_abs_error"] for r in rows])
    ax.loglog(gs, errs, "o-", linewidth=1.6, label="exact vs third-order effective")
    ax.loglog(gs, errs[0]*(gs/gs[0])**4, "--", linewidth=1.2, label=r"reference slope $4$")
    ax.set_xlabel(r"clock-assisted coupling $g/E_P$")
    ax.set_ylabel(r"maximum low-energy spectral discrepancy ($E_P$ units)")
    ax.grid(True, which="both", linewidth=0.35, alpha=0.5)
    ax.legend(frameon=False)
    ax.set_title(fr"Tetrahedral FCC fragment: fitted slope {slope:.3f}")
    fig.tight_layout()
    fig.savefig(outdir / "fig5_sw_convergence.pdf", bbox_inches="tight")
    fig.savefig(outdir / "fig5_sw_convergence.png", dpi=250, bbox_inches="tight")
    plt.close(fig)
    return rows, slope


def tetrahedron_dynamics(beta: float = 0.2, eta: float = 0.5, u: float = 2.3):
    n_sites = 4
    dm = 4
    dc = 16
    j0, g = beta*(1.0-eta/2.0), beta*eta/2.0
    h, _, _, _ = tetrahedron_exact_and_effective(j0, g)
    # Restrict to one matter excitation.
    matter_indices = [s for s in range(16) if s.bit_count() == 1]
    inds = [s*dc+c for s in matter_indices for c in range(dc)]
    h1 = h[np.ix_(inds, inds)]
    vals, vecs = eigh(h1)
    # basis is matter occupation states in ascending bit pattern; site 0 is state 1.
    initial_matter = np.zeros(dm, dtype=complex)
    initial_matter[0] = 1.0  # bit pattern 0001, excitation on site 0
    initial_clock = np.ones(dc, dtype=complex)/np.sqrt(dc)  # |tau_0>^tensor4
    psi0 = np.kron(initial_matter, initial_clock)
    coeff = vecs.conj().T @ psi0
    psit = vecs @ (np.exp(-1j*vals*u)*coeff)
    psi_matrix = psit.reshape(dm, dc)
    probs = np.sum(np.abs(psi_matrix)**2, axis=1)
    norm = float(np.vdot(psit, psit).real)
    e0 = float(np.vdot(psi0, h1@psi0).real)
    et = float(np.vdot(psit, h1@psit).real)
    return probs, norm, e0, et


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", default=str(Path(__file__).resolve().parents[1]/"figures"))
    args = parser.parse_args()
    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)

    geometry_checks = validate_fcc_geometry()
    make_fcc_geometry_figure(outdir)
    make_fcc_laplacian_figure(outdir)
    make_clock_figure(outdir)
    make_pair_transfer_figure(outdir)
    sw_rows, sw_slope = make_sw_figure(outdir)

    pair_checks = []
    for beta, eta, u in [(0.2,0.0,8.0),(0.2,0.5,8.0),(0.2,1.0,8.0),(0.13,0.7,2.3)]:
        pm = pair_transfer_probability(beta, eta, u)
        pc = pair_transfer_closed_form(beta, eta, u)
        pair_checks.append({"beta":beta,"eta":eta,"u":u,"matrix":pm,"closed_form":pc,"abs_diff":abs(pm-pc)})
        assert abs(pm-pc) < 2e-12

    occ, norm, e0, et = tetrahedron_dynamics()
    assert abs(occ.sum()-1.0) < 2e-12 and abs(norm-1.0) < 2e-12 and abs(e0-et) < 2e-12

    # Algebraic checks on the full 256-dimensional tetrahedral Hamiltonian.
    h, _, ks, tmat = tetrahedron_exact_and_effective(j0=0.1, g=0.05)
    n_ops, _ = matter_operators(4)
    n_m = sum(n_ops, np.zeros_like(n_ops[0]))
    parity_clock = np.diag([(-1)**s.bit_count() for s in range(16)]).astype(complex)
    n_total = np.kron(n_m, np.eye(16))
    parity_total = np.kron(np.eye(16), parity_clock)
    checks = {
      "hermiticity_frobenius_norm": float(np.linalg.norm(h-h.conj().T)),
      "matter_number_commutator_frobenius_norm": float(np.linalg.norm(h@n_total-n_total@h)),
      "clock_parity_commutator_frobenius_norm": float(np.linalg.norm(h@parity_total-parity_total@h)),
      "matter_sector_occupations_sum": float(occ.sum()),
      "time_evolution_norm": norm,
      "energy_initial": e0,
      "energy_final": et,
    }
    assert checks["hermiticity_frobenius_norm"] < 1e-12
    assert checks["matter_number_commutator_frobenius_norm"] < 1e-12
    assert checks["clock_parity_commutator_frobenius_norm"] < 1e-12

    output = {
      "units": "hbar=t_P=E_P=1; Delta=pi",
      "geometry_checks": geometry_checks,
      "pair_matrix_vs_closed_form": pair_checks,
      "tetrahedron_SW_convergence_all_matter_sectors": sw_rows,
      "tetrahedron_SW_fitted_loglog_slope": sw_slope,
      "tetrahedron_one_excitation_dynamics": {
        "beta":0.2,"eta":0.5,"u":2.3,"site_occupations":occ.tolist(),"checks":checks
      },
    }
    (outdir/"simulation_results.json").write_text(json.dumps(output, indent=2))
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
