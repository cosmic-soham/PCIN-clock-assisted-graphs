#!/usr/bin/env python3
"""Exhaustive parity-closure audit for edge multisets on simple graphs n<=5."""
from __future__ import annotations
import itertools
import json
from pathlib import Path


def graph_edge_sets(n):
    possible = list(itertools.combinations(range(n), 2))
    for graph_mask in range(1 << len(possible)):
        yield [possible[i] for i in range(len(possible)) if (graph_mask >> i) & 1]


def parity_mask_for_sequence(sequence):
    mask = 0
    for i, j in sequence:
        mask ^= (1 << i) | (1 << j)
    return mask


def main():
    graphs = sequences = closed = 0
    r3_closed = r3_triangle = r4_closed = r4_square = r4_even_multiplicity = 0
    for n in range(1, 6):
        for edges in graph_edge_sets(n):
            graphs += 1
            for r in range(1, 7):
                for seq in itertools.combinations_with_replacement(edges, r):
                    sequences += 1
                    is_closed = parity_mask_for_sequence(seq) == 0
                    if is_closed:
                        closed += 1
                    if r == 3 and is_closed:
                        r3_closed += 1
                        if len(set(seq)) == 3:
                            edge_set = set(seq)
                            used = set(itertools.chain.from_iterable(edge_set))
                            assert len(used) == 3 and all(sum(v in e for e in edge_set) == 2 for v in used)
                            r3_triangle += 1
                    if r == 4 and is_closed:
                        r4_closed += 1
                        counts = {e: seq.count(e) for e in set(seq)}
                        odd_edges = {e for e, c in counts.items() if c % 2}
                        if not odd_edges:
                            assert sorted(counts.values()) in ([4], [2, 2])
                            r4_even_multiplicity += 1
                        else:
                            assert len(odd_edges) == 4
                            used = set(itertools.chain.from_iterable(odd_edges))
                            assert len(used) == 4 and all(sum(v in e for e in odd_edges) == 2 for v in used)
                            r4_square += 1
    result = {
        "scope": "all labelled simple graphs with 1-5 vertices; edge multisets up to six W insertions",
        "labelled_graphs": graphs,
        "edge_multisets_checked": sequences,
        "clock_parity_closed_multisets": closed,
        "order_3_closed_multisets": r3_closed,
        "order_3_distinct_edge_triangles": r3_triangle,
        "order_4_closed_multisets": r4_closed,
        "order_4_four_cycle_multisets": r4_square,
        "order_4_even_multiplicity_multisets": r4_even_multiplicity,
        "interpretation": "Parity closure is necessary for a nonzero projected clock matrix element; it is not a fourth-order SW coefficient calculation.",
    }
    target = Path(__file__).resolve().parents[1] / "results" / "clock_parity_audit.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
