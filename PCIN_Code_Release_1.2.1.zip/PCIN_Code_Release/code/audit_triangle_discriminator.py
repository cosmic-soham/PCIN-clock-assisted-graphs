#!/usr/bin/env python3
"""Check the local motif data for a proposed third-order discriminator.

The triangular-prism graph and K_3,3 are both 3-regular six-vertex graphs
with nine edges.  Their triangle counts differ, which makes them a useful
coefficient-level comparison for the third-order PCIN graph-motif formula.

This script checks only graph combinatorics and predicted motif labels.  It
performs no quantum simulation and is not experimental validation.
"""
from __future__ import annotations

import itertools
import json
from pathlib import Path


def stats(n: int, edges: list[tuple[int, int]]) -> dict:
    edge_set = {tuple(sorted(e)) for e in edges}
    degrees = [0] * n
    tau_v = [0] * n
    tau_e = {e: 0 for e in sorted(edge_set)}
    triangles: list[tuple[int, int, int]] = []

    for u, v in edge_set:
        degrees[u] += 1
        degrees[v] += 1

    for i, j, k in itertools.combinations(range(n), 3):
        tri_edges = ((i, j), (i, k), (j, k))
        if all(e in edge_set for e in tri_edges):
            triangles.append((i, j, k))
            for v in (i, j, k):
                tau_v[v] += 1
            for e in tri_edges:
                tau_e[e] += 1

    return {
        "vertices": n,
        "edges": len(edge_set),
        "degree_sequence": degrees,
        "triangle_count": len(triangles),
        "triangles": [list(t) for t in triangles],
        "triangles_per_vertex_tau_i": tau_v,
        "triangles_per_edge_tau_ij": {
            f"{u}-{v}": count for (u, v), count in sorted(tau_e.items())
        },
        "edge_counts_by_triangle_incidence": {
            "tau_ij_0": sum(x == 0 for x in tau_e.values()),
            "tau_ij_1": sum(x == 1 for x in tau_e.values()),
            "tau_ij_ge_2": sum(x >= 2 for x in tau_e.values()),
        },
    }


def main() -> None:
    # Two triangular 3-cycles joined by a perfect matching.
    prism = [
        (0, 1), (1, 2), (0, 2),
        (3, 4), (4, 5), (3, 5),
        (0, 3), (1, 4), (2, 5),
    ]
    # Complete bipartite graph with parts {0,1,2} and {3,4,5}.
    k33 = [(u, v) for u in range(3) for v in range(3, 6)]

    result = {
        "scope": "combinatorial audit of a proposed graph pair; no Hamiltonian simulation",
        "triangular_prism": stats(6, prism),
        "K_3_3": stats(6, k33),
        "comparison": {
            "same_vertex_count": True,
            "same_edge_count": True,
            "same_degree_sequence": True,
            "degree_controlled_terms_match": True,
            "triangle_motif_data_differ": True,
        },
    }

    a = result["triangular_prism"]
    b = result["K_3_3"]
    assert a["vertices"] == b["vertices"] == 6
    assert a["edges"] == b["edges"] == 9
    assert a["degree_sequence"] == b["degree_sequence"] == [3] * 6
    assert a["triangle_count"] == 2 and b["triangle_count"] == 0
    assert a["triangles_per_vertex_tau_i"] == [1] * 6
    assert b["triangles_per_vertex_tau_i"] == [0] * 6
    assert a["edge_counts_by_triangle_incidence"] == {
        "tau_ij_0": 3, "tau_ij_1": 6, "tau_ij_ge_2": 0
    }
    assert b["edge_counts_by_triangle_incidence"] == {
        "tau_ij_0": 9, "tau_ij_1": 0, "tau_ij_ge_2": 0
    }

    out = Path(__file__).resolve().parents[1] / "results" / "triangle_discriminator_graphs.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
