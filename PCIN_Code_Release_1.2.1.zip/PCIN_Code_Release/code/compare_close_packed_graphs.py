#!/usr/bin/env python3
"""Audit local degree/triangle signatures of ideal periodic FCC and HCP graphs.

The construction is combinatorial with periodic boundary conditions. It checks
vertex degree, triangles per vertex, and common-neighbour counts (triangles per
edge). It does not compare spectra or thermodynamic energies.
"""
from __future__ import annotations
import itertools
import json
import math
from collections import Counter
from pathlib import Path


def graph_signature(vertices, edges):
    neighbours = {v: set() for v in vertices}
    for a, b in edges:
        if a == b:
            raise RuntimeError("Unexpected self-loop in periodic quotient")
        neighbours[a].add(b)
        neighbours[b].add(a)
    degree_hist = Counter(map(len, neighbours.values()))
    triangles_per_vertex = {}
    for v in vertices:
        ns = sorted(neighbours[v])
        triangles_per_vertex[v] = sum(1 for a, b in itertools.combinations(ns, 2) if b in neighbours[a])
    triangles_per_edge = {tuple(sorted((a, b))): len(neighbours[a] & neighbours[b]) for a, b in edges}
    return {
        "vertices": len(vertices),
        "edges": len(edges),
        "degree_histogram": {str(k): v for k, v in sorted(degree_hist.items())},
        "triangles_per_vertex_histogram": {str(k): v for k, v in sorted(Counter(triangles_per_vertex.values()).items())},
        "triangles_per_edge_histogram": {str(k): v for k, v in sorted(Counter(triangles_per_edge.values()).items())},
        "all_degrees_12": all(x == 12 for x in degree_hist),
        "all_vertices_in_24_triangles": all(x == 24 for x in triangles_per_vertex.values()),
        "all_edges_in_4_triangles": all(x == 4 for x in triangles_per_edge.values()),
    }


def fcc_graph(L: int = 5):
    vertices = list(itertools.product(range(L), repeat=3))
    b1 = (0.0, 1 / math.sqrt(2), 1 / math.sqrt(2))
    b2 = (1 / math.sqrt(2), 0.0, 1 / math.sqrt(2))
    b3 = (1 / math.sqrt(2), 1 / math.sqrt(2), 0.0)
    def sub(a, b): return tuple(a[i] - b[i] for i in range(3))
    def norm(v): return math.sqrt(sum(x*x for x in v))
    positive = [((1, 0, 0), b1), ((0, 1, 0), b2), ((0, 0, 1), b3),
                ((1, -1, 0), sub(b1, b2)), ((1, 0, -1), sub(b1, b3)),
                ((0, 1, -1), sub(b2, b3))]
    bond_lengths = [norm(cart) for _, cart in positive]
    if max(abs(x - 1.0) for x in bond_lengths) > 1e-12:
        raise RuntimeError(f"FCC primitive nearest-neighbour vectors are not unit length: {bond_lengths}")
    edges = set()
    for v in vertices:
        for d, _ in positive:
            w = tuple((v[i] + d[i]) % L for i in range(3))
            edges.add(tuple(sorted((v, w))))
    result = graph_signature(vertices, edges)
    result["nearest_neighbour_bond_length_min"] = min(bond_lengths)
    result["nearest_neighbour_bond_length_max"] = max(bond_lengths)
    return result


def hcp_graph(Lx: int = 5, Ly: int = 5, Lz: int = 4):
    # Hexagonal Bravais cell with a two-site basis (A at z=0, B at z=1/2).
    # a1=(1,0,0), a2=(1/2,sqrt(3)/2,0), c=(0,0,sqrt(8/3));
    # the B basis offset is (a1+a2)/3 + c/2.
    a1 = (1.0, 0.0, 0.0)
    a2 = (0.5, math.sqrt(3.0) / 2.0, 0.0)
    c = (0.0, 0.0, math.sqrt(8.0 / 3.0))
    def vec(*terms):
        return tuple(sum(coeff * v[q] for coeff, v in terms) for q in range(3))
    def norm(v): return math.sqrt(sum(x*x for x in v))
    layer_vectors = [a1, a2, vec((1.0, a1), (-1.0, a2))]
    lateral_holes = [vec((1/3, a1), (1/3, a2)),
                     vec((-2/3, a1), (1/3, a2)),
                     vec((1/3, a1), (-2/3, a2))]
    vertical = tuple(x / 2.0 for x in c)
    bond_vectors = list(layer_vectors)
    for sign in (1.0, -1.0):
        bond_vectors.extend(vec((1.0, h), (sign, vertical)) for h in lateral_holes)
    bond_lengths = [norm(v) for v in bond_vectors]
    if len(bond_lengths) != 9 or max(abs(x - 1.0) for x in bond_lengths) > 1e-12:
        raise RuntimeError(f"HCP nearest-neighbour geometry check failed: {bond_lengths}")
    vertices = [(s, i, j, k) for s in (0, 1)
                for i in range(Lx) for j in range(Ly) for k in range(Lz)]
    edges = set()

    def add(a, b):
        if a != b:
            edges.add(tuple(sorted((a, b))))

    # Six triangular-layer neighbours per site.
    for sublattice in (0, 1):
        for i, j, k in itertools.product(range(Lx), range(Ly), range(Lz)):
            a = (sublattice, i, j, k)
            for di, dj in ((1, 0), (0, 1), (1, -1)):
                b = (sublattice, (i + di) % Lx, (j + dj) % Ly, k)
                add(a, b)

    # Each A site has three B neighbours above and three below.
    for i, j, k in itertools.product(range(Lx), range(Ly), range(Lz)):
        a = (0, i, j, k)
        for dk in (0, -1):
            for di, dj in ((0, 0), (-1, 0), (0, -1)):
                b = (1, (i + di) % Lx, (j + dj) % Ly, (k + dk) % Lz)
                add(a, b)
    result = graph_signature(vertices, edges)
    result["nearest_neighbour_bond_length_min"] = min(bond_lengths)
    result["nearest_neighbour_bond_length_max"] = max(bond_lengths)
    return result


def main():
    result = {
        "scope": "local graph signatures of ideal periodic nearest-neighbour FCC and AB-stacked HCP graphs",
        "caveat": "Different adjacency operators; no equality of spectra or energies is claimed.",
        "fcc_5x5x5_primitive_supercell": fcc_graph(5),
        "hcp_5x5x4_two_site_basis_supercell": hcp_graph(5, 5, 4),
    }
    for key in ("fcc_5x5x5_primitive_supercell", "hcp_5x5x4_two_site_basis_supercell"):
        x = result[key]
        if not (x["all_degrees_12"] and x["all_vertices_in_24_triangles"] and x["all_edges_in_4_triangles"]):
            raise RuntimeError(f"Local motif count check failed for {key}: {x}")
    target = Path(__file__).resolve().parents[1] / "results" / "close_packed_graph_audit.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
