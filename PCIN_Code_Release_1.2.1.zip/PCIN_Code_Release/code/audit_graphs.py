import itertools, numpy as np
from pathlib import Path
from scipy.linalg import eigh

def graph_matrices(n, edges):
    dim=1<<n
    nops=[np.zeros((dim,dim),complex) for _ in range(n)]
    K={e:np.zeros((dim,dim),complex) for e in edges}
    for s in range(dim):
        for i in range(n):
            if (s>>i)&1: nops[i][s,s]=1
        for i,j in edges:
            bi,bj=(s>>i)&1,(s>>j)&1
            if bi!=bj:
                K[(i,j)][s ^ (1<<i) ^ (1<<j),s]=1
    return nops,K

def make_graph_test(n, edges, g, J0, Delta=np.pi):
    edges=tuple(sorted(tuple(sorted(e)) for e in edges))
    dm=dc=1<<n; d=dm*dc
    nops,K=graph_matrices(n,edges)
    N=sum(nops,np.zeros((dm,dm),complex))
    T=sum(K.values(),np.zeros((dm,dm),complex))
    # construct full Hamiltonian by direct basis bit flips; independent from Kronecker assembly
    H=np.zeros((d,d),complex)
    for m in range(dm):
      for c in range(dc):
        idx=m*dc+c
        H[idx,idx]=Delta*c.bit_count()
        for i in range(n):
          if (m>>i)&1: H[idx,idx]+=0.0
        for i,j in edges:
          mb=(m>>i)&1; nb=(m>>j)&1
          if mb != nb:
            mp=m^(1<<i)^(1<<j)
            H[mp*dc+c,idx]+=J0
            cp=c^(1<<i)^(1<<j)
            H[mp*dc+cp,idx]+=g
    # Build the reduced degree/triangle form of the SW theorem directly.
    degrees=[0]*n; tri_v=[0]*n; tri_e={e:0 for e in edges}
    edge_set=set(edges); triangles=[]
    for i,j in edges: degrees[i]+=1; degrees[j]+=1
    for i,j,k in itertools.combinations(range(n),3):
      tri_edges=[(i,j),(i,k),(j,k)]
      if all(e in edge_set for e in tri_edges):
        triangles.append((i,j,k))
        for v in (i,j,k): tri_v[v]+=1
        for e in tri_edges: tri_e[e]+=1
    Heff=np.zeros((dm,dm),complex)
    for i in range(n):
      Heff += (-degrees[i]*g*g/(2*Delta)+tri_v[i]*g**3/(2*Delta**2))*nops[i]
    for e in edges:
      i,j=e
      Heff += (g*g/Delta-tri_e[e]*g**3/(2*Delta**2))*(nops[i]@nops[j])
      Heff += (J0-(degrees[i]+degrees[j]-2)*g*g*J0/(8*Delta**2))*K[e]
    # Compare exact lowest |matter states| eigenvalues separately in N sectors.
    errs=[]
    for q in range(n+1):
      ms=[s for s in range(dm) if s.bit_count()==q]
      inds=[m*dc+c for m in ms for c in range(dc)]
      ev=eigh(H[np.ix_(inds,inds)],eigvals_only=True,subset_by_index=[0,len(ms)-1])
      ee=eigh(Heff[np.ix_(ms,ms)],eigvals_only=True)
      errs.append(np.max(np.abs(ev-ee)))
    return max(errs)

def audit_motif_identities():
    # Exhaustive all labelled simple graphs n=1..5: double-commutator identity.
    # The triangle operator identity is checked for every triangle in every graph.
    max_mismatch=0.0; max_triangle_mismatch=0.0; count=0; triangle_count=0; max_reduction_mismatch=0.0
    for n in range(1,6):
      possible=list(itertools.combinations(range(n),2))
      for mask in range(1<<len(possible)):
        edges=[possible[i] for i in range(len(possible)) if (mask>>i)&1]
        nops,K=graph_matrices(n,edges); dim=1<<n
        T=sum(K.values(),np.zeros((dim,dim),complex))
        lhs=np.zeros_like(T); rhs=np.zeros_like(T)
        deg=[0]*n
        for i,j in edges: deg[i]+=1;deg[j]+=1
        for f in edges:
          lhs += K[f]@ (K[f]@T-T@K[f]) - (K[f]@T-T@K[f])@K[f]
        for i,j in edges:
          rhs += (deg[i]+deg[j]-2)*K[(i,j)]
        err=np.linalg.norm(lhs-rhs)
        max_mismatch=max(max_mismatch,err); count+=1
        edge_set=set(edges)
        for i,j,k in itertools.combinations(range(n),3):
          tri_edges=[(i,j),(i,k),(j,k)]
          if all(e in edge_set for e in tri_edges):
            lhs_tri=np.zeros_like(T)
            for order in itertools.permutations(tri_edges):
              lhs_tri += K[order[0]]@K[order[1]]@K[order[2]]
            nops,_=graph_matrices(n,edges)
            rhs_tri=2*(nops[i]+nops[j]+nops[k]-nops[i]@nops[j]-nops[j]@nops[k]-nops[k]@nops[i])
            max_triangle_mismatch=max(max_triangle_mismatch,np.linalg.norm(lhs_tri-rhs_tri))
            triangle_count+=1
        # Compare the operator SW expression with its degree/triangle-count reduction.
        deg=[0]*n; tri_v=[0]*n; tri_e={e:0 for e in edges}
        tris=[]
        for i,j in edges: deg[i]+=1; deg[j]+=1
        for i,j,k in itertools.combinations(range(n),3):
          te=[(i,j),(i,k),(j,k)]
          if all(e in edge_set for e in te):
            tris.append(te)
            for v in (i,j,k): tri_v[v]+=1
            for e in te: tri_e[e]+=1
        g0=0.137; j0=0.211; Delta=1.73
        hop=j0*T.copy()
        for e in edges: hop += -g0*g0*j0/(8*Delta**2)*(K[e]@(K[e]@T-T@K[e])-(K[e]@T-T@K[e])@K[e])
        diag=np.zeros_like(T)
        for e in edges: diag += -g0*g0/(2*Delta)*(K[e]@K[e])
        triop=np.zeros_like(T)
        for tri in tris:
          for order in itertools.permutations(tri): triop += g0**3/(4*Delta**2)*(K[order[0]]@K[order[1]]@K[order[2]])
        op_eff=hop+diag+triop
        red_eff=np.zeros_like(T)
        for v in range(n): red_eff += (-deg[v]*g0*g0/(2*Delta)+tri_v[v]*g0**3/(2*Delta**2))*nops[v]
        for e in edges:
          i,j=e
          red_eff += (g0*g0/Delta-tri_e[e]*g0**3/(2*Delta**2))*(nops[i]@nops[j])
          red_eff += (j0-(deg[i]+deg[j]-2)*g0*g0*j0/(8*Delta**2))*K[e]
        max_reduction_mismatch=max(max_reduction_mismatch,np.linalg.norm(op_eff-red_eff))
    return count,max_mismatch,triangle_count,max_triangle_mismatch,max_reduction_mismatch

if __name__=='__main__':
    import json, hashlib, platform, scipy
    count,err,ntri,trierr,red_err=audit_motif_identities()
    print('graphs checked',count,'max double-commutator mismatch',err)
    print('triangles checked',ntri,'max triangle-identity mismatch',trierr)
    print('max full-SW to degree/triangle reduction mismatch',red_err)
    tests={
      'P3':(3,[(0,1),(1,2)]),
      'K3':(3,[(0,1),(0,2),(1,2)]),
      'star_K1_3':(4,[(0,1),(0,2),(0,3)]),
      'C4':(4,[(0,1),(1,2),(2,3),(0,3)]),
      'diamond':(4,[(0,1),(0,2),(1,2),(1,3),(2,3)]),
      'K4':(4,list(itertools.combinations(range(4),2)))
    }
    gs=np.array([0.003,0.005,0.008,0.012,0.018,0.025])
    rows=[]
    for name,(n,edges) in tests.items():
      vals=[float(make_graph_test(n,edges,g,J0=2*g)) for g in gs]
      slope=float(np.polyfit(np.log(gs),np.log(vals),1)[0])
      rows.append({'graph':name,'vertices':n,'edges':len(edges),'triangles':sum(1 for tri in itertools.combinations(range(n),3) if all(tuple(sorted(e)) in set(edges) for e in itertools.combinations(tri,2))), 'max_degree':max(sum(1 for e in edges if v in e) for v in range(n)), 'fitted_slope':slope,'g_over_EP':gs.tolist(),'max_sector_spectral_errors':vals})
      print(name,'slope',slope,'errors',vals)
    result={'scope':'finite simple graphs only','units':'hbar=1, Delta=pi, J0=2g','identity_checks':{'labelled_graphs_n_1_to_5':count,'max_double_commutator_frobenius_mismatch':float(err),'triangle_instances_checked':ntri,'max_triangle_identity_frobenius_mismatch':float(trierr),'max_operator_to_degree_triangle_reduction_frobenius_mismatch':float(red_err)},'spectral_checks':rows,'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__}}
    script_dir=Path(__file__).resolve().parent
    root=script_dir.parent if script_dir.name=='code' else script_dir
    outdir=root/'results'; outdir.mkdir(parents=True,exist_ok=True)
    with open(outdir/'graph_audit_results.json','w') as f: json.dump(result,f,indent=2)
    print('wrote',outdir/'graph_audit_results.json')
