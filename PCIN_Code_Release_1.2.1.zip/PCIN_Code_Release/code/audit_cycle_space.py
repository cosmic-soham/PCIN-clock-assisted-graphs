#!/usr/bin/env python3
"""Verify the GF(2) cycle-space formulation of clock-parity closure.

For every labelled simple graph with 1--5 vertices, enumerate all edge
subsets, retain those with even degree at every vertex, and compare their
number with 2**(m - n + c), where c is the number of connected components.
This checks a graph-theoretic counting identity; it does not calculate
Schrieffer--Wolff coefficients.
"""
from __future__ import annotations
import itertools
import json
from pathlib import Path


def edge_sets(n: int):
    possible = list(itertools.combinations(range(n), 2))
    for mask in range(1 << len(possible)):
        yield [possible[k] for k in range(len(possible)) if (mask >> k) & 1]


def component_count(n: int, edges: list[tuple[int, int]]) -> int:
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)
    seen = set()
    count = 0
    for root in range(n):
        if root in seen:
            continue
        count += 1
        stack = [root]
        seen.add(root)
        while stack:
            u = stack.pop()
            for v in adj[u]:
                if v not in seen:
                    seen.add(v)
                    stack.append(v)
    return count


def even_degree_subset_count(n: int, edges: list[tuple[int, int]]) -> int:
    total = 0
    for mask in range(1 << len(edges)):
        parity = [0] * n
        for k, (u, v) in enumerate(edges):
            if (mask >> k) & 1:
                parity[u] ^= 1
                parity[v] ^= 1
        total += (not any(parity))
    return total


def main():
    graphs = subsets = closed_subsets = 0
    max_abs_count_error = 0
    max_cycle_rank = 0
    for n in range(1, 6):
        for edges in edge_sets(n):
            graphs += 1
            m = len(edges)
            c = component_count(n, edges)
            beta = m - n + c
            predicted = 1 << beta
            observed = even_degree_subset_count(n, edges)
            max_abs_count_error = max(max_abs_count_error, abs(observed - predicted))
            if observed != predicted:
                raise AssertionError((n, edges, observed, predicted))
            subsets += 1 << m
            closed_subsets += observed
            max_cycle_rank = max(max_cycle_rank, beta)
    result = {
        "scope": "all labelled simple graphs with 1-5 vertices; all edge subsets",
        "labelled_graphs": graphs,
        "edge_subsets_examined": subsets,
        "parity_closed_subsets": closed_subsets,
        "max_abs_error_vs_2_power_cycle_rank": max_abs_count_error,
        "max_cycle_rank_encountered": max_cycle_rank,
        "identity": "number of even-degree edge subsets = 2^(|E|-|V|+c(G))",
        "interpretation": "The clock-return supports form the graph cycle space over GF(2). This is a selection/counting rule, not a perturbative coefficient calculation.",
    }
    out = Path(__file__).resolve().parents[1] / "results" / "cycle_space_audit.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
