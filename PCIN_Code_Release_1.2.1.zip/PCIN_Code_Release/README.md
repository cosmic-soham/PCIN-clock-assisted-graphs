# PCIN Paper I — code and reproducibility release

**Release:** 1.2.1  
**Date prepared:** 26 November 2026  
**Author:** Soham Deshmukh  
**Associated manuscript:** *PCIN: Clock-Assisted Hard-Core-Boson Dynamics on Finite Graphs: Graph-Motif-Dependent Effective Interactions and an FCC Realisation* (26-page working manuscript; separate file).

This repository contains the Python code and machine-readable outputs supporting the associated PCIN Paper I manuscript. It is a finite-dimensional quantum-lattice-model study, not an experimentally validated theory of physical spacetime.

## Contents

- `code/reproduce_pcin.py` — FCC Voronoi geometry, exact two-cell transfer, tetrahedral-fragment exact diagonalisation, and figure generation.
- `code/audit_graphs.py` — separate direct-bit-flip microscopic Hamiltonians, finite-graph spectra, and exhaustive small-graph motif identities.
- `code/audit_clock_parity.py` — edge-multiset enumeration for the clock-parity closure rule.
- `code/audit_cycle_space.py` — verifies that parity-closed edge supports form the binary cycle space and that their count is $2^{|E|-|V|+c(G)}$ on all labelled simple graphs with 1--5 vertices.
- `code/compare_close_packed_graphs.py` — periodic local graph-signature comparison of ideal FCC and AB-stacked HCP nearest-neighbour graphs.
- `code/audit_triangle_discriminator.py` — checks the matched-degree triangular-prism versus $K_{3,3}$ graph pair proposed as a future coefficient-level test.
- `results/*.json` — saved numerical outputs from the audits.
- `figures/` — generated PDF/PNG plots and primary simulation output JSON.
- `requirements.txt` — tested Python package versions.
- `CITATION.cff` — software citation metadata.

## Reproduction

Tested with Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, and Matplotlib 3.10.8.

```bash
python -m venv .venv
source .venv/bin/activate        # Linux/macOS
# .venv\\Scripts\\activate     # Windows PowerShell
python -m pip install -r requirements.txt

python code/reproduce_pcin.py --outdir figures
python code/audit_graphs.py
python code/audit_clock_parity.py
python code/audit_cycle_space.py
python code/compare_close_packed_graphs.py
python code/audit_triangle_discriminator.py
```

The numerical audits are finite-size checks. They do not establish a periodic-FCC thermodynamic limit, a size-uniform Schrieffer–Wolff remainder estimate, physical spacetime discreteness, or geometry selection.

## Main numerical checks

- Direct matrix exponentiation and the closed-form two-cell transfer probability agree to a maximum absolute difference of approximately `1.33e-15` on the supplied test points.
- The tetrahedral four-site FCC-fragment low-energy spectral discrepancy has a fitted log-log slope of `4.0156103546` over the tested weak-coupling interval. This is consistent with a fourth-order residual on that fixed cluster, not a proof of an asymptotic or volume-uniform bound.
- The separate graph code path checks `P3`, `K3`, `K1,3`, `C4`, a diamond graph, and `K4`.
- Algebraic checks cover all 1,099 labelled simple graphs with one through five vertices.
- The cycle-space audit checks all 59,809 edge subsets across 1,099 labelled simple graphs with 1--5 vertices; the count of even-degree subsets matches $2^{|E|-|V|+c(G)}$ exactly.
- The proposed triangle discriminator has equal vertex count, edge count, and degree sequence in the triangular prism and $K_{3,3}$, but two triangles versus zero; the new script checks this graph combinatorics only.
- Clock-parity enumeration checks 773,177 edge multisets (up to six assisted-edge insertions) across those graphs. It does not calculate fourth-order Schrieffer–Wolff coefficients.
- Periodic ideal FCC/HCP local motif counts agree at degree 12, 24 triangles per vertex, and four triangles per edge. The adjacency operators, spectra, and energies are not claimed to be equal.

Full scope, derivations, caveats, and manuscript references are in the associated paper, not reproduced here.

## Licensing — action required before public release

No licence has been added because the author must choose the reuse terms. For original research code, MIT is a simple permissive option. Do not assume that a code licence also licenses manuscript text or figures. Add the chosen licence before making the repository public and before requesting a Zenodo software archive. This local package has not been uploaded to GitHub or Zenodo and has no DOI yet.

## Recommended citation

Cite the version-specific Zenodo DOI after it has actually been minted. Until then, cite the associated manuscript by author, title, and version date, and do not invent a DOI.
