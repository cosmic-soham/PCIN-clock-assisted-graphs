# Changelog

## 1.1.0 — 26 November 2026

- Reorganised Paper I around the arbitrary-finite-graph third-order Hermitian Schrieffer–Wolff result and its FCC realisation.
- Added the exact clock-parity closure proposition for virtual edge sequences and a finite enumeration audit; explicitly did not claim a completed fourth-order effective Hamiltonian.
- Added periodic ideal FCC versus AB-stacked HCP local-motif enumeration, documenting the inability of degree/triangle coefficients at third order alone to select the stacking.
- Added separate reproducibility scripts and machine-readable outputs for parity and close-packed graph checks.
- Rebuilt the manuscript in a 12 pt A4 working format and re-ran all four reproduction/audit scripts.
- Retained explicit limitations on finite-volume perturbation theory, thermodynamic limits, geometry selection, and physical spacetime interpretation.


## 1.2.0 — 26 November 2026

- Added the binary cycle-space audit for parity-closed edge supports.
- Updated software citation metadata and associated manuscript title.


## 1.2.1 — 26 November 2026

- Added `audit_triangle_discriminator.py` and its JSON output to verify the local-motif contrast between the six-site triangular prism and $K_{3,3}$.
- This is a graph-combinatorics check for a proposed future experiment, not a quantum-dynamics simulation or experimental result.
